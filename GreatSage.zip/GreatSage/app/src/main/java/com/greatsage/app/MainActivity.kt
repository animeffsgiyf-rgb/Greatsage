package com.greatsage.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

enum class SageMode { CHAT, ACTION }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GreatSageHome() }
    }
}

@Composable
fun GreatSageHome() {
    var mode by remember { mutableStateOf(SageMode.CHAT) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0B0F1A))
            .padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("GREAT SAGE", color = Color(0xFF7CF5FF), fontSize = 32.sp)
        Spacer(Modifier.height(8.dp))
        Text("Status: Ready (v0.1 foundation)", color = Color.White, fontSize = 14.sp)
        Spacer(Modifier.height(32.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            if (mode == SageMode.CHAT) {
                Button(onClick = { mode = SageMode.CHAT }) { Text("Chat Mode") }
                OutlinedButton(onClick = { mode = SageMode.ACTION }) { Text("Action Mode") }
            } else {
                OutlinedButton(onClick = { mode = SageMode.CHAT }) { Text("Chat Mode") }
                Button(onClick = { mode = SageMode.ACTION }) { Text("Action Mode") }
            }
        }
        Spacer(Modifier.height(24.dp))
        Text("Current mode: ${mode.name}", color = Color(0xFFB0B8C8), fontSize = 14.sp)
    }
}
